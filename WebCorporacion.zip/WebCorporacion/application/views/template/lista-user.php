<!-- INICIO LISTA -->
<div class="row-fluid">
   <div id="jm-content" class="span9 offset3" data-xtablet="span12" data-tablet="span12" data-mobile="span12">
      <div id="jm-maincontent">
         <div id="dj-classifieds" class="clearfix djcftheme-jm-dating">
            <div class="djcf-ad-top clearfix">
               <div class="moduletable">
                  <div class="custom"  >
                     <p style="margin: 0; text-align: center;">
                        <a href="http://dj-extensions.com/faq/dj-classifieds-faq/how-to-place-a-banner-adsense-into-dj-classifieds" target="_blank"><img src="jm-dating/images/modules/banner.png" alt="Custom Banner" border="0" /></a>
                     </p>
                  </div>
               </div>
            </div>
            <h1 class="main_cat_title">She's looking for Him<a
               class="rss_icon" href="jm-dating/meet-somebody/she-s-looking-for-him?format=feed&amp;type=rss">
               <img src="jm-dating/components/com_djclassifieds/assets/images/rss.png"  alt="rss" /></a>
            </h1>
            <div class="dj-items-blog">
               <div class="djcf_items_blog">
                  <div class="item_box item_auction" style="width:24.9%;">
                     <div class="item_box_bg0">
                        <div class="item_box_in">
                           <div class="item_box_in2 clearfix">
                              <div class="title">
                                 <h2><a href="jm-dating/single-ad-view-with-bids" >Vivian White</a></h2>
                                 <span class="type_button" style="display:inline-block; border:0px solid #DEDEDE;background:#6B4ECC;color:#FFFFFF;font-size: 10px;font-weight: bold;line-height: 20px;margin: 2px;padding: 0 5px;vertical-align:middle;" >FREEKY</span>
                                 <span class="auction_icon" ></span>
                              </div>
                              <div class="blog_det">
                                 <div class="item_img">
                                    <a href="jm-dating/single-ad-view-with-bids">
                                    <img src="jm-dating/components/com_djclassifieds/images/item/78_i14_thm.jpg" alt="i14"  /></a>
                                 </div>
                                 <div class="region">
                                    <span class="label_title"></span>New York
                                 </div>
                                 <div class="item_box_bottom">
                                    <div class="item_desc">
                                       <span class="label_title">About me</span>
                                       <span class="desc_info">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span>
                                    </div>
                                 </div>
                                 <div class="see_details_box">
                                    <a class="see_details" href="jm-dating/single-ad-view-with-bids" >More about me</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="item_box" style="width:24.9%;">
                     <div class="item_box_bg1">
                        <div class="item_box_in">
                           <div class="item_box_in2 clearfix">
                              <div class="title">
                                 <h2> <a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/felicia-owen,76" >Felicia Owen </a></h2>
                                 <span class="type_button" style="display:inline-block;border:0px solid #DEDEDE;background:#FF4A62;color:#000000;font-size: 10px;font-weight: bold;line-height: 20px;margin: 2px;padding: 0 5px;vertical-align:middle;" >JOYFUL</span>
                              </div>
                              <div class="blog_det">
                                 <div class="item_img">
                                    <a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/felicia-owen,76">
                                    <img src="jm-dating/components/com_djclassifieds/images/item/76_i8_thm.jpg" alt="i8"  /></a>
                                 </div>
                                 <div class="region">
                                    <span class="label_title"></span>Chicago
                                 </div>
                                 <div class="item_box_bottom">
                                    <div class="item_desc">
                                       <span class="label_title">About me</span>
                                       <span class="desc_info">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span>
                                    </div>
                                 </div>
                                 <div class="see_details_box">
                                    <a class="see_details" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/felicia-owen,76" >More about me</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="item_box" style="width:24.9%;">
                     <div class="item_box_bg2">
                        <div class="item_box_in">
                           <div class="item_box_in2 clearfix">
                              <div class="title">
                                 <h2><a href="jm-dating/single-ad-view-with-horizontal-search" >Angel Brown</a></h2>
                              </div>
                              <div class="blog_det">
                                 <div class="item_img">
                                    <a href="jm-dating/single-ad-view-with-horizontal-search">
                                    <img src="jm-dating/components/com_djclassifieds/images/item/75_i6_thm.jpg" alt="i6"  /></a>
                                 </div>
                                 <div class="region">
                                    <span class="label_title"></span>New York
                                 </div>
                                 <div class="item_box_bottom">
                                    <div class="item_desc">
                                       <span class="label_title">About me</span>
                                       <span class="desc_info">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span>
                                    </div>
                                 </div>
                                 <div class="see_details_box">
                                    <a class="see_details" href="jm-dating/single-ad-view-with-horizontal-search" >More about me</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="item_box promotion p_border p_bg" style="width:24.9%;">
                     <div class="item_box_bg3 last_col">
                        <div class="item_box_in">
                           <div class="item_box_in2 clearfix">
                              <div class="title">
                                 <h2><a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/cathy-hale,69" >Cathy Hale </a></h2>
                              </div>
                              <div class="blog_det">
                                 <div class="item_img">
                                    <a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/cathy-hale,69">
                                    <img src="jm-dating/components/com_djclassifieds/images/item/69_i20_thm.jpg" alt="i20"  /></a>
                                 </div>
                                 <div class="region">
                                    <span class="label_title"></span>Los Angeles
                                 </div>
                                 <div class="item_box_bottom">
                                    <div class="item_desc"><span class="label_title">About me</span>
                                       <span class="desc_info">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span>
                                    </div>
                                 </div>
                                 <div class="see_details_box">
                                    <a class="see_details" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/cathy-hale,69" >More about me</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="item_box promotion p_bg" style="width:24.9%;">
                     <div class="item_box_bg0">
                        <div class="item_box_in">
                           <div class="item_box_in2 clearfix">
                              <div class="title">
                                 <h2><a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/jane-cobb,68" >Jane Cobb </a></h2>
                                 <span class="type_button" style="display:inline-block;border:0px solid #DEDEDE;background:#70B00E;color:#FFFFFF;font-size: 10px;font-weight: bold;line-height: 20px;margin: 2px;padding: 0 5px;vertical-align:middle;" >LONELY</span>
                              </div>
                              <div class="blog_det">
                                 <div class="item_img">
                                    <a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/jane-cobb,68">
                                    <img src="jm-dating/components/com_djclassifieds/images/item/68_i16_thm.jpg" alt="i16"  /></a>
                                 </div>
                                 <div class="region">
                                    <span class="label_title"></span>Chicago
                                 </div>
                                 <div class="item_box_bottom">
                                    <div class="item_desc">
                                       <span class="label_title">About me</span>
                                       <span class="desc_info">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span>
                                    </div>
                                 </div>
                                 <div class="see_details_box">
                                    <a class="see_details" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/jane-cobb,68" >More about me</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="item_box" style="width:24.9%;">
                     <div class="item_box_bg1">
                        <div class="item_box_in">
                           <div class="item_box_in2 clearfix">
                              <div class="title">
                                 <h2><a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/julie-ortega,64" >Julie Ortega</a></h2>
                              </div>
                              <div class="blog_det">
                                 <div class="item_img">
                                    <a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/julie-ortega,64">
                                    <img src="jm-dating/components/com_djclassifieds/images/item/64_i10_thm.jpg" alt="i10"  /></a>
                                 </div>
                                 <div class="region">
                                    <span class="label_title"></span>New York
                                 </div>
                                 <div class="item_box_bottom">
                                    <div class="item_desc"><span class="label_title">About me</span><span
                                       class="desc_info">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></div>
                                 </div>
                                 <div class="see_details_box">
                                    <a class="see_details" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/julie-ortega,64" >More about me</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="item_box" style="width:24.9%;">
                     <div class="item_box_bg2">
                        <div class="item_box_in">
                           <div class="item_box_in2 clearfix">
                              <div class="title">
                                 <h2><a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/anne-james,59" >Anne James</a></h2>
                              </div>
                              <div class="blog_det">
                                 <div class="item_img"><a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/anne-james,59">
                                    <img src="jm-dating/components/com_djclassifieds/images/item/59_i4_thm.jpg" alt="i4"  /></a>
                                 </div>
                                 <div class="region"><span class="label_title"></span>New York</div>
                                 <div class="item_box_bottom">
                                    <div class="item_desc"><span class="label_title">About me</span>
                                       <span class="desc_info">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span>
                                    </div>
                                 </div>
                                 <div class="see_details_box">
                                    <a class="see_details" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/anne-james,59" >More about me</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="item_box" style="width:24.9%;">
                     <div class="item_box_bg3 last_col">
                        <div class="item_box_in">
                           <div class="item_box_in2 clearfix">
                              <div class="title">
                                 <h2><a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/angie-briggs,58" >Angie Briggs</a></h2>
                              </div>
                              <div class="blog_det">
                                 <div class="item_img">
                                    <a href="jm-dating/meet-somebody/she-s-looking-for-him/ad/angie-briggs,58">
                                    <img src="jm-dating/components/com_djclassifieds/images/item/58_i2_thm.jpg" alt="i2"  /></a>
                                 </div>
                                 <div class="region"><span class="label_title"></span>Los Angeles</div>
                                 <div class="item_box_bottom">
                                    <div class="item_desc"><span class="label_title">About me</span>
                                       <span class="desc_info">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span>
                                    </div>
                                 </div>
                                 <div class="see_details_box">
                                    <a class="see_details" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/angie-briggs,58" >More about me</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="clear_both" ></div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!--SLIDER LEFT-->
   <!-- FIN SLIDER -->
</div>
<!--Fin  lista-->
