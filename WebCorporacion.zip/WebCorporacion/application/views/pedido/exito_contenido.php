	<!--inicio formulario contacto-->
			<div class="page-header">
                    <div class="container-fluid">
                        <ol class="breadcrumb">
                            <li><a href="index.html">Pedido</a></li>
                            <li class="active">Confirmaci&oacute;n</li>
                        </ol>
                    </div><!-- End .container-fluid -->
                </div><!-- End .page-header -->

                <div class="container-fluid">
                    <div class="row">
                    
                        <div class="col-md-9 ">
                           

                            <h2> Pedido recibido</h2>
                            <div class="row row-lg table-row">
                            
                            <p>
                            Gracias por contactarnos en breve le enviaremos la 
                            cotizaci&oacute;n de su pedido.
                            </p>
                            <p>
                            Le hemos enviado una copia al email proporcionado.
                            </p>
                            
                                
                            </div><!-- End .row -->

                            <div class="mb100 mb80-sm"></div><!-- margin -->

                            <div class="contact-infos-wrapper">
                                <div class="row">
                                    <div class="col-sm-4 contact-info-container">
                                        <div class="contact-info">
                                            <i class="icon contact-icon contact-pin"></i>
                                            <div class="contact-info-meta">
                                                <h3>Nuestra Ubicaci&oacute;n</h3>
                                                <address>
                                                    Jr. San Diego 171- Surquillo (Alt. Puente Ricardo Palma c/ V&iacute;a Expresa)
                                                </address>
                                                <a href="#" class="more-link">Leer m&aacute;s</a>
                                            </div><!-- end .contact-info-meta -->
                                        </div><!-- End .contact-info -->
                                    </div><!-- End .col-sm-4 -->
                                    <div class="col-sm-4 contact-info-container">
                                        <div class="contact-info">
                                            <i class="icon contact-icon contact-email"></i>
                                            <div class="contact-info-meta">
                                                <h3>Detalles de Contacto</h3>
                                                <ul>
                                                    <li><span>Correo:</span> <a href="mailto:#">ventas@corporacionderepuestos.com</a></li>
                                                    <li><span>Skype:</span> cr_servicios</li>
                                                </ul>
                                                <a href="#" class="more-link">Leer m&aacute;s</a>
                                            </div><!-- end .contact-info-meta -->
                                        </div><!-- End .contact-info -->
                                    </div><!-- End .col-sm-4 -->
                                    <div class="col-sm-4 contact-info-container">
                                        <div class="contact-info">
                                            <i class="icon contact-icon contact-phone"></i>
                                            <div class="contact-info-meta">
                                                <h3>Cont&aacute;ctenos</h3>
                                                <ul>
                                                    <li><span>Tel&eacute;fono:</span>51 01 242-4595</li>
                                                    <li><span>Celular:</span>968 990 826</li>
                                                </ul>
                                                <a href="#" class="more-link">LEER M&Aacute;S</a>
                                            </div><!-- end .contact-info-meta -->
                                        </div><!-- End .contact-info -->
                                    </div><!-- End .col-sm-4 -->
                                </div><!-- End .row -->
                            </div><!-- End .contact-infos-wrapper -->
                        </div><!-- End .col-md-9 -->

                        <div class="mb80 mb70-xs visible-sm visible-xs"></div><!-- margin -->

                       
                    </div><!-- End .row -->
                </div><!-- End .container-fluid -->
                <div class="mb90 visible-md visible-lg"></div><!-- margin -->
			<!--FIN FORMULARIO COMENNTARIO-->