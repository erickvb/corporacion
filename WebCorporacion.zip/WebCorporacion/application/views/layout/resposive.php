<div
id="jm-offcanvas"><div
id="jm-offcanvas-toolbar">
<a
class="toggle-nav close-menu"><span
class="icon-remove"></span></a></div><div
id="jm-offcanvas-content" class="jm-offcanvas"><div
class="jm-module "><div
class="jm-module-in"><div
class="jm-module-content clearfix notitle"><div
class="custom"  ><p>Assign modules on offcanvas module position to make them visible in the sidebar.</p></div></div></div></div><div
class="jm-module  title-small-ms"><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Menu</span></h3></div><div
class="jm-module-content clearfix "><ul
class="nav menu"><li
class="item-470 current active parent"><a
href="jm-dating/" >Home</a></li><li
class="item-550 parent"><a
href="jm-dating/meet" >Meet somebody</a></li><li
class="item-475 parent"><a
href="https://www.joomla-monster.com/knowledge-base-area/templates-documentation/general-info-ef4-framework-for-joomla-3-x/framework-ver-ef4" target="_blank" >Template</a></li><li
class="item-583 parent"><a
href="jm-dating/left-content-right" >Pages</a></li><li
class="item-487 parent"><a
href="jm-dating/album-grid" >Extensions</a></li><li
class="item-472 divider parent"><span
class="separator">
Languages</span></li><li
class="item-620 divider parent"><span
class="separator">
Styles</span></li></ul></div></div></div><div
class="jm-module _menu tags-ms title-small-ms"><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Categories</span></h3></div><div
class="jm-module-content clearfix "><div
class="djcf_menu"><ul
class="menu nav _menu tags-ms title-small-ms"><li
class=""><a
href="jm-dating/meet-somebody/he-s-looking-for-her">He's looking for Her</a></li><li
class=""><a
href="jm-dating/meet-somebody/she-s-looking-for-him">She's looking for Him</a></li><li
class=""><a
href="jm-dating/meet-somebody/she-s-looking-for-her">She's looking for Her - Adults only</a></li><li
class=""><a
href="jm-dating/meet-somebody/he-s-looking-for-him">He's looking for Him</a></li></ul></div></div></div></div><div
class="jm-module  title-small-ms"><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Love</span> story !</h3></div><div
class="jm-module-content clearfix "><div
class="custom title-small-ms"  ><p><a
href="jm-dating/contact"><img src="jm-dating/images/modules/banner-bottom.jpg" alt="Love Story" /></a></p></div></div></div></div></div></div>