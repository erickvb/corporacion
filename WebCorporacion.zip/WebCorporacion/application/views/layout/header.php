 		<meta charset="utf-8">
        <title>Sconto - Premium eCommerce Template</title>
        <meta name="description" content="Premium eCommerce Template">

        <!--[if IE]> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <![endif]-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Favicon -->
        <link rel="icon" type="image/png" href="<?=base_url()?>public/assets/images/favicons/favicon.png">
        <link rel="apple-touch-icon" sizes="57x57" href="<?=base_url()?>public/assets/images/favicons/faviconx57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="<?=base_url()?>public/assets/images/favicons/faviconx72.png">

        <link href='http://fonts.googleapis.com/css?family=Hind:400,700,600,500,300%7CFira+Sans:400,700italic,500italic,400italic,300italic,700,500,300' rel='stylesheet' type='text/css'>

        <!-- Fira Sans Fix - Google Fira Sans sometimes fails to load -->
        <link href='http://code.cdn.mozilla.net/fonts/fira.css' rel='stylesheet'>

        <link rel="stylesheet" href="<?=base_url()?>public/assets/css/plugins.min.css">
        <link rel="stylesheet" href="<?=base_url()?>public/assets/css/style.css">
        <script type="text/javascript">
        var URL_SITE_WEB ="<?=site_url()?>";
        </script>
 		
 		
	   	
	  