<section id="jm-header" class="">

<div id="jm-header-bg" class="">
<div class="jm-module  navigation-ms description-ms pagination-ms"><div
class="jm-module-in">
<div class="jm-title-wrap"><h3 class="jm-title "><span>Header</span> Background Slideshow</h3></div><div
class="jm-module-content clearfix ">
<div style="border: 0px !important;">
	<div id="dj-slideshow28m251" class="dj-slideshow">
		<div class="dj-slideshow-in">
		<div class="dj-slides"><div
class="dj-slide"><div
class="dj-slide-in">
<img src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/images/modules/header/1903x550-crop-90-header2.jpg"  data-srcset="jm-dating/media/djmediatools/cache/images/modules/header/1903x550-crop-90-header2.jpg 1903w, jm-dating/media/djmediatools/cache/images/modules/header/_980w/1903x550-crop-90-header2.jpg 980w, jm-dating/media/djmediatools/cache/images/modules/header/_768w/1903x550-crop-90-header2.jpg 768w, jm-dating/media/djmediatools/cache/images/modules/header/_480w/1903x550-crop-90-header2.jpg 480w, jm-dating/media/djmediatools/cache/images/modules/header/_320w/1903x550-crop-90-header2.jpg 320w, jm-dating/media/djmediatools/cache/images/modules/header/_240w/1903x550-crop-90-header2.jpg 240w, jm-dating/media/djmediatools/cache/images/modules/header/_160w/1903x550-crop-90-header2.jpg 160w, jm-dating/media/djmediatools/cache/images/modules/header/_120w/1903x550-crop-90-header2.jpg 120w, jm-dating/media/djmediatools/cache/images/modules/header/_80w/1903x550-crop-90-header2.jpg 80w" data-sizes="100vw" alt="header 2" class="dj-image" width="1903" height="550" /></div></div><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-description"><div
class="jm-custom-title"><p>Meet <span
class="color">people</span></p><p>from all over the <span
class="color">World!</span></p></div></div><div
style="clear: both"></div></div></div></div><div
class="dj-slide"><div
class="dj-slide-in">
<img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/images/modules/header/1903x550-crop-90-header3.jpg"  data-srcset="jm-dating/media/djmediatools/cache/images/modules/header/1903x550-crop-90-header3.jpg 1903w, jm-dating/media/djmediatools/cache/images/modules/header/_980w/1903x550-crop-90-header3.jpg 980w, jm-dating/media/djmediatools/cache/images/modules/header/_768w/1903x550-crop-90-header3.jpg 768w, jm-dating/media/djmediatools/cache/images/modules/header/_480w/1903x550-crop-90-header3.jpg 480w, jm-dating/media/djmediatools/cache/images/modules/header/_320w/1903x550-crop-90-header3.jpg 320w, jm-dating/media/djmediatools/cache/images/modules/header/_240w/1903x550-crop-90-header3.jpg 240w, jm-dating/media/djmediatools/cache/images/modules/header/_160w/1903x550-crop-90-header3.jpg 160w, jm-dating/media/djmediatools/cache/images/modules/header/_120w/1903x550-crop-90-header3.jpg 120w, jm-dating/media/djmediatools/cache/images/modules/header/_80w/1903x550-crop-90-header3.jpg 80w" data-sizes="100vw" alt="header 3" class="dj-image" width="1903" height="550" /></div></div><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-description"><div
class="jm-custom-title"><p>Contact <span
class="color">him</span></p><p>Maybe it's your <span
class="color">love!</span></p></div></div><div
style="clear: both"></div></div></div></div><div
class="dj-slide"><div
class="dj-slide-in">
<img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/images/modules/header/1903x550-crop-90-header.jpg"  data-srcset="jm-dating/media/djmediatools/cache/images/modules/header/1903x550-crop-90-header.jpg 1903w, jm-dating/media/djmediatools/cache/images/modules/header/_980w/1903x550-crop-90-header.jpg 980w, jm-dating/media/djmediatools/cache/images/modules/header/_768w/1903x550-crop-90-header.jpg 768w, jm-dating/media/djmediatools/cache/images/modules/header/_480w/1903x550-crop-90-header.jpg 480w, jm-dating/media/djmediatools/cache/images/modules/header/_320w/1903x550-crop-90-header.jpg 320w, jm-dating/media/djmediatools/cache/images/modules/header/_240w/1903x550-crop-90-header.jpg 240w, jm-dating/media/djmediatools/cache/images/modules/header/_160w/1903x550-crop-90-header.jpg 160w, jm-dating/media/djmediatools/cache/images/modules/header/_120w/1903x550-crop-90-header.jpg 120w, jm-dating/media/djmediatools/cache/images/modules/header/_80w/1903x550-crop-90-header.jpg 80w" data-sizes="100vw" alt="header" class="dj-image" width="1903" height="550" /></div></div><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-description"><div
class="jm-custom-title"><p>Find <span
class="color">her</span></p><p>She's waiting for <span
class="color">you!</span></p></div></div><div
style="clear: both"></div>
</div>
</div>
</div>
</div>
<!--FIN-->
<div class="dj-navigation">
<div
class="dj-navigation-in">
<img
class="dj-prev showOnMouseOver" src="jm-dating/images/modules/navi/transparent.png" alt="Previous" />
<img
class="dj-next showOnMouseOver" src="jm-dating/images/modules/navi/transparent.png" alt="Next" />
<img
class="dj-play showOnMouseOver" src="jm-dating/images/modules/navi/play.png" alt="Play" />
<img
class="dj-pause showOnMouseOver" src="jm-dating/images/modules/navi/pause.png" alt="Pause" /></div></div><div
class="dj-indicators "><div
class="dj-indicators-in">
<span
class="dj-load-button dj-load-button-active"><span
class="dj-key">1</span></span>
<span
class="dj-load-button"><span
class="dj-key">2</span></span>
<span
class="dj-load-button"><span
class="dj-key">3</span></span></div></div><div
class="dj-loader"></div></div></div></div><div 
style="clear: both"></div></div></div></div></div>
<div id="jm-header-content" class="container-fluid">
	 
	<? //include("search.php")?>
	
</div>
</div>

</section>