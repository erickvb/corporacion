<section id="jm-bottom1" class="">
<div class="container-fluid">
<div class="row-fluid jm-flexiblock jm-bottom1">
<div class="span6"  data-default="span6" data-wide="span6" data-normal="span6" data-xtablet="span6" data-tablet="span100" data-mobile="span100"><div
class="row-fluid">
<div class="span0"><div
class="jm-module  grid-ms"><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Top</span> trending interests</h3></div><div
class="jm-module-content clearfix "><div
id="dj-galleryGrid29m256" class="dj-galleryGrid"><div
class="dj-galleryGrid-in"><div
class="dj-slides"><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Travels" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-travel.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-travel.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-travel.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-travel.jpg 80w" data-sizes="100vw" alt="Travels" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Travels" target="_self">										Travels									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Animals" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-animals.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-animals.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-animals.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-animals.jpg 80w" data-sizes="100vw" alt="Animals" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Animals" target="_self">										Animals									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Cars" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-cars.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-cars.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-cars.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-cars.jpg 80w" data-sizes="100vw" alt="Cars" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Cars" target="_self">										Cars									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Drinking" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-drikning.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-drikning.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-drikning.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-drikning.jpg 80w" data-sizes="100vw" alt="Drikning" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Drinking" target="_self">										Drikning									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Food" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-food.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-food.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-food.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-food.jpg 80w" data-sizes="100vw" alt="Food" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Food" target="_self">										Food									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Movie" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-movie.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-movie.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-movie.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-movie.jpg 80w" data-sizes="100vw" alt="Movie" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Movie" target="_self">										Movie									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Music" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-music.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-music.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-music.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-music.jpg 80w" data-sizes="100vw" alt="Music" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Music" target="_self">										Music									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Party" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-party.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-party.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-party.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-party.jpg 80w" data-sizes="100vw" alt="Party" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Party" target="_self">										Party									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Photography" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-photography.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-photography.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-photography.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-photography.jpg 80w" data-sizes="100vw" alt="Photography" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Photography" target="_self">										Photography									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Sport" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-sport.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-sport.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-sport.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-sport.jpg 80w" data-sizes="100vw" alt="Sport" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Sport" target="_self">										Sport									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Technology" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-technology.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-technology.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-technology.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-technology.jpg 80w" data-sizes="100vw" alt="Technology" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Technology" target="_self">										Technology									</a></div><div
style="clear: both"></div></div></div></div></div></div><div
class="dj-slide " ><div
class="dj-slide-in">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Architecture" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache/126x126-crop-90-architecture.jpg"  data-srcset="jm-dating/media/djmediatools/cache/126x126-crop-90-architecture.jpg 126w, jm-dating/media/djmediatools/cache/_120w/126x126-crop-90-architecture.jpg 120w, jm-dating/media/djmediatools/cache/_80w/126x126-crop-90-architecture.jpg 80w" data-sizes="100vw" alt="Architecture" class="dj-image" width="126" height="126" /></a><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet?se=1&amp;ef=1&amp;se_61[0]=Architecture" target="_self">										Architecture									</a></div><div
style="clear: both"></div></div></div></div></div></div></div><div
style="clear: both"></div></div></div></div></div></div></div></div></div><div
class="span6"  data-default="span6" data-wide="span6" data-normal="span6" data-xtablet="span6" data-tablet="span100 first-span" data-mobile="span100 first-span"><div
class="row-fluid"><div
class="span0"><div
class="jm-module "><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Find</span> people from your city</h3></div><div
class="jm-module-content clearfix "><div
class="dj_cf_maps"><div
id="djmod_map_box257" style="display:none;"><div
id='djmod_map257' class="djmod_map" style='width: 100%; height: 480px; border: 1px solid #666; '></div></div></div> <script type="text/javascript">window.addEvent('domready', function(){
		djmodMapaClusterStart257();
		});

         var djmod_map257;
         var djmod_map_marker257 = new google.maps.InfoWindow();
         var djmod_geokoder257 = new google.maps.Geocoder();
		 var djmarkers257 = new Array();		
		    	
		function djmodMarker(position,txt,icon)
		{			
		    var MarkerOptions =  
		    { 
		        position: position, 
		        icon: icon
		    } 
		    var marker = new google.maps.Marker(MarkerOptions);
		    marker.txt=txt;
		     
		    google.maps.event.addListener(marker,"click",function()
		    {
		        djmod_map_marker257.setContent(marker.txt);
		        djmod_map_marker257.open(djmod_map257,marker);
		    });
		    return marker;
		}   	
		    	
		 function djmodMapaClusterStart257()    
		 {   		 

			djmod_geokoder257.geocode({address: 'New York, Manhattan'}, function (results, status)
			{
			    if(status == google.maps.GeocoderStatus.OK)
			    {			    
				 document.getElementById("djmod_map_box257").style.display='block';
				 							var map_center = results[0].geometry.location;
								 	 
				    var opcjeMapy = {
				        zoom: 12,
				        center: map_center,
				  		mapTypeId: google.maps.MapTypeId.ROADMAP,
				  		navigationControl: true,
				  		scrollwheel: true,
				  		styles:[{
					        featureType:"poi",
					        elementType:"labels",
					        stylers:[{
					            visibility:"off"
					        }]
					    }]
				    };
				    djmod_map257 = new google.maps.Map(document.getElementById("djmod_map257"), opcjeMapy); 				    				    
					 var size = new google.maps.Size(32,32);
	                 var start_point = new google.maps.Point(0,0);
	                 var anchor_point = new google.maps.Point(0,16);	            			 
												var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(40.745280500000000,-73.991422200000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/single-ad-view-with-bids "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/78_i14_ths.jpg" /> <strong>Vivian White</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(40.793337000000000,-73.967587000000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/single-ad-view-with-buy-now "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/77_i24_ths.jpg" /> <strong>Henry Garrett </strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(41.894443200000000,-87.641243100000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/felicia-owen,76 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/76_i8_ths.jpg" /> <strong>Felicia Owen </strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(40.754709900000000,-73.992006800000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/single-ad-view-with-horizontal-search "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/75_i6_ths.jpg" /> <strong>Angel Brown</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(34.030182600000000,-118.273518000000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/he-s-looking-for-him/ad/willie-brown,74 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/74_i22_ths.jpg" /> <strong>Willie Brown </strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(34.049543000000000,-118.257453000000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/she-s-looking-for-her/ad/erica-brooks,73 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/73_i2_ths.jpg" /> <strong>Erica Brooks</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(41.898561500000000,-87.621398200000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/she-s-looking-for-her/ad/karen-mills,72 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/72_i23_ths.jpg" /> <strong>Karen Mills </strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(34.101312000000000,-118.347540000000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/he-s-looking-for-her/ad/jamie-cole,71 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/71_i18_ths.jpg" /> <strong>Jamie Cole </strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(41.912673600000000,-87.634737200000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/cf-single-ad-view "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/70_i19_ths.jpg" /> <strong>Andy Burton</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(34.104971900000000,-118.334360000000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/cathy-hale,69 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/69_i20_ths.jpg" /> <strong>Cathy Hale </strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(41.981924700000000,-87.660022700000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/jane-cobb,68 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/68_i16_ths.jpg" /> <strong>Jane Cobb </strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(40.769040600000000,-73.943539500000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/he-s-looking-for-her/ad/phil-ellis,67 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/67_i15_ths.jpg" /> <strong>Phil Ellis</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(41.845369400000000,-87.621577000000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/she-s-looking-for-her/ad/mae-doyle,66 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/66_i12_ths.jpg" /> <strong>Mae Doyle </strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(34.080131400000000,-118.337065000000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/he-s-looking-for-her/ad/pete-haynes,65 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/65_i13_ths.jpg" /> <strong>Pete Haynes</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(40.761862800000000,-73.983333200000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/julie-ortega,64 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/64_i10_ths.jpg" /> <strong>Julie Ortega</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(41.736541600000000,-87.545833300000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/he-s-looking-for-her/ad/daniel-reid,63 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/63_i11_ths.jpg" /> <strong>Daniel Reid</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(40.782337700000000,-73.971830000000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/he-s-looking-for-him/ad/spencer-poole,62 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/62_i9_ths.jpg" /> <strong>Spencer Poole</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(34.103094300000000,-118.308794700000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/she-s-looking-for-her/ad/ann-alexander,61 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/61_i8_ths.jpg" /> <strong>Ann Alexander </strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(41.795803900000000,-87.586013000000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/he-s-looking-for-her/ad/hugo-hernandez,60 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/60_i7_ths.jpg" /> <strong>Hugo Hernandez</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    								var icon = '';
																																			
																	var adLatlng = new google.maps.LatLng(40.740710800000000,-73.927745300000000);
										djmarkers257.push(djmodMarker(adLatlng,'<div style="width:200px;margin-bottom:0px"><div style="margin-bottom:5px;"><a style="text-decoration:none !important;" href="jm-dating/meet-somebody/she-s-looking-for-him/ad/anne-james,59 "><img style="float:left;margin:5px 10px 0 0;"  width="60px" src="http://templates.joomla-monster.comjm-dating//components/com_djclassifieds/images/item/59_i4_ths.jpg" /> <strong>Anne James</strong><br /><span style="color:#333333">Donec ut quam felis. Cras egestas, quam in plac erat dictum, erat mauris inte rdum est nec.</span></a></div></div>',icon));
				    											
				    		
				    	var mcOptions = {gridSize: 50, maxZoom: 14,styles: [{
						height: 53,url: "http://templates.joomla-monster.com/joomla30/jm-dating/components/com_djclassifieds/assets/mapclustering/images/m1.png",width: 53},
						{height: 56,url: "http://templates.joomla-monster.com/joomla30/jm-dating/components/com_djclassifieds/assets/mapclustering/images/m2.png",width: 56},
						{height: 66,url: "http://templates.joomla-monster.com/joomla30/jm-dating/components/com_djclassifieds/assets/mapclustering/images/m3.png",width: 66},
						{height: 78,url: "http://templates.joomla-monster.com/joomla30/jm-dating/components/com_djclassifieds/assets/mapclustering/images/m4.png",width: 78},
						{height: 90,url: "http://templates.joomla-monster.com/joomla30/jm-dating/components/com_djclassifieds/assets/mapclustering/images/m5.png",width: 90}]};
				    	var markerCluster = new MarkerClusterer(djmod_map257, djmarkers257,mcOptions);																																									    
			    	}
				});					    
		    }</script> 
			</div>
			</div>
			</div>
			</div>
			</div>
			</div>
			</div>
			</div>
</section>

