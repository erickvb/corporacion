<div class="socials-section smaller">
                                <div id="socials-feed-slider" class="carousel slide" data-ride="carousel" data-interval="7000">
                                    <div class="carousel-inner">
                                        <div class="item active container-fluid" style='background-image: url(<?=base_url()?>public/assets/images/socials/twitterbg.jpg)'>
                                
                                <img src="<?=base_url()?>public/assets/images/socials/twitter.png" alt="twitter" class="social-show-icon">

                                            <h2>ULTIMOS TWEETS</h2>

                                            <div class="socials-twitter-container">
                                                <div class="swiper-container socials-twitter-slider">
                                                    <div class="swiper-wrapper">

                                                        <div class="swiper-slide">
                                                                <p>Mauris vestibulum dui nec dolor blandit tempor. Mauris convallis lectus et dignissim posuere. Duis convallis finibus libero quis rutrum. In venenatis vehicula dictum. Phasellus laoreet felis ut consectetur placerat.</p>

                                                                <span>12 April 2016</span>
                                                        </div><!-- End .swiper-slide -->

                                                        <div class="swiper-slide ">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam vitae provident in nemo placeat ullam nobis omnis, consequatur, quaerat cum eos aperiam optio, hic deserunt quas enim corporis, minima! Dolore eu ligula nibh astus dictum.</p>

                                                            <span>17 April 2016</span>
                                                        </div><!-- End .swiper-slide -->

                                                        <div class="swiper-slide">
                                                            <p>Assumenda nobis, officiis non nemo nulla laborum, delectus accusamus qui esse ratione mollitia adipisci aspernatur architecto voluptatum ullam reprehenderit ab fuga doloremque dignissimos culpa, porro harum libero repellendus quasi.</p>

                                                            <span>09 April 2016</span>
                                                        </div><!-- End .swiper-slide -->

                                                    </div><!-- End .swiper-wrapper -->
                                                </div><!-- End .swiper-container -->
                                            </div><!-- End .socials-twitter-container -->

                                        </div><!-- End .item -->

                                       <div class="item container-fluid" style='background-image: url(<?=base_url()?>public/assets/images/socials/twitterbg.jpg)'>
                                <img src="<?=base_url()?>public/assets/images/socials/facebook.png" alt="facebook" class="social-show-icon">

                                            <h2>OUR FANS</h2>

                                            <div class="socials-facebook-container">
                                                <div class="row">
                                                    <div class="f-section">
                                                        <a href="#">
                                                            <img src="<?=base_url()?>public/assets/images/facebook/user1.jpg" alt="User">
                                                        </a>
                                                    </div><!-- End .f-section -->
                                                    <div class="f-section">
                                                        <a href="#">
                                                            <img src="<?=base_url()?>public/assets/images/facebook/user2.jpg" alt="User">
                                                        </a>
                                                    </div><!-- End .f-section -->
                                                    <div class="f-section">
                                                        <a href="#">
                                                            <img src="<?=base_url()?>public/assets/images/facebook/user3.jpg" alt="User">
                                                        </a>
                                                    </div><!-- End .f-section -->
                                                    <div class="f-section">
                                                        <a href="#">
                                                            <img src="<?=base_url()?>public/assets/images/facebook/user4.jpg" alt="User">
                                                        </a>
                                                    </div><!-- End .f-section -->
                                                    <div class="f-section">
                                                        <a href="#">
                                                            <img src="<?=base_url()?>public/assets/images/facebook/user5.jpg" alt="User">
                                                        </a>
                                                    </div><!-- End .f-section -->
                                                    <div class="f-section">
                                                        <a href="#">
                                                            <img src="<?=base_url()?>public/assets/images/facebook/user6.jpg" alt="User">
                                                        </a>
                                                    </div><!-- End .f-section -->
                                                    <div class="f-section">
                                                        <a href="#">
                                                            <img src="<?=base_url()?>public/assets/images/facebook/user7.jpg" alt="User">
                                                        </a>
                                                    </div><!-- End .f-section -->
                                                </div><!-- End .row -->

                                                <div class="f-action">
                                                    <a href="#" class="btn btn-border btn-white">LIKE US</a>
                                                    <span>55.000 Fans</span>
                                                </div><!-- end .f-action -->
                                            </div><!-- End .socials-facebook-container -->
                                        </div><!-- End .item -->

                                       <div class="item container-fluid" style='background-image: url(<?=base_url()?>public/assets/images/socials/twitterbg.jpg)'>
                                <img src="<?=base_url()?>public/assets/images/socials/youtube.png" alt="youtube" class="social-show-icon">

                                            <h2>LATEST VIDEO</h2>
                                            <div class="socials-youtube-container">
                                                
                                                <a href="#" class="btn btn-custom">SUBSCRIBE</a>
                                            </div><!-- end .socials-youtube-container -->
                                        </div><!-- End .item -->
                                    </div><!-- End .carousel-inner -->

                                    <!-- Indicators -->
                                    <ol class="carousel-indicators">
                                        <li data-target="#socials-feed-slider" data-slide-to="0" class="active">
                                            <span class="feed-icon icon icon-twitter"></span>
                                        </li>
                                        <li data-target="#socials-feed-slider" data-slide-to="1">
                                            <span class="feed-icon icon icon-facebook"></span>
                                        </li>
                                        <li data-target="#socials-feed-slider" data-slide-to="2">
                                            <span class="feed-icon icon icon-youtube"></span>
                                        </li>
                                    </ol>
                                </div><!-- End .carousel -->
                            </div><!-- End .socials-section -->