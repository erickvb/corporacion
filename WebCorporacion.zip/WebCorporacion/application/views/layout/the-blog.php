<div class="swiper-container fromblog-smaller-carousel">
                                <div class="carousel-header bordered">
                                    <h2 class="carousel-title text-center">FROM THE BLOG</h2>
                                    <div class="swiper-nav-wrapper">
                                        <div class="swiper-button-prev icon"></div><!-- End .button-prev -->
                                        <div class="swiper-button-next icon"></div><!-- End .button-next -->
                                    </div><!-- End .swiper-nav-wrapper -->
                                </div><!-- End .carousel-header -->

                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <article class="entry entry-small">
                                            <figure class="entry-media">
                                                <a href="single.html">
                                                    <img src="assets/images/blog/index5/post1.jpg" alt="Entry">
                                                </a>
                                            </figure>
                                            <div class="entry-content-wrapper">
                                                <span class="entry-date">12 November</span>
                                                <h2 class="entry-title">
                                                    <a href="single.html">Curabitur Faucibus Aliquam Felis</a>
                                                </h2>
                                                <div class="entry-content">
                                                    <p>Vivamus mollis varius metus in egestas. Vestibulum blandit auctor dolor. Praesent iaculis ultrices accumsan. Integer sollicitu din consectetur lectus, vitae vulputate velit pharetra sed. Nunc ac lobortis velit, eu tempus tellus.</p>
                                                </div><!-- End .entry-excerpt -->
                                                <a href="sigle.html" class="btn btn-custom btn-readmore">READ MORE</a>
                                            </div><!-- End .entry-content-wrapper -->
                                        </article>
                                    </div><!-- End .swiper-slide -->

                                    <div class="swiper-slide">
                                        <article class="entry entry-small">
                                            <figure class="entry-media">
                                                <a href="single.html">
                                                    <img src="assets/images/blog/index5/post2.jpg" alt="Entry">
                                                </a>
                                            </figure>
                                            <div class="entry-content-wrapper">
                                                <span class="entry-date">25 November</span>
                                                <h2 class="entry-title">
                                                    <a href="single.html">Suspendisse Laoreet Sagittis</a>
                                                </h2>
                                                <div class="entry-content">
                                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate convallis nulla at faucibus tellus commodo id. Sed metus eros, dapibus id porttitor ac, viverra vitae urna Integer interdum ultricies malesuada. Donec nisl lorem, dictum sit amet lectus.</p>
                                                </div><!-- End .entry-excerpt -->
                                                <a href="sigle.html" class="btn btn-custom btn-readmore">READ MORE</a>
                                            </div><!-- End .entry-content-wrapper -->
                                        </article>
                                    </div><!-- End .swiper-slide -->

                                    <div class="swiper-slide">
                                        <article class="entry entry-small">
                                            <figure class="entry-media">
                                                <a href="single.html">
                                                    <img src="assets/images/blog/index5/post3.jpg" alt="Entry">
                                                </a>
                                            </figure>
                                            <div class="entry-content-wrapper">
                                                <span class="entry-date">06 December</span>
                                                <h2 class="entry-title">
                                                    <a href="single.html">volutpat sit felis mollis</a>
                                                </h2>
                                                <div class="entry-content">
                                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate convallis nulla at faucibus tellus commodo id. Sed metus eros, dapibus id porttitor ac, viverra vitae urna Integer interdum ultricies malesuada. Donec nisl lorem, dictum sit amet lectus.</p>
                                                </div><!-- End .entry-excerpt -->
                                                <a href="sigle.html" class="btn btn-custom btn-readmore">READ MORE</a>
                                            </div><!-- End .entry-content-wrapper -->
                                        </article>
                                    </div><!-- End .swiper-slide -->

                                    <div class="swiper-slide">
                                        <article class="entry entry-small">
                                            <figure class="entry-media">
                                                <a href="single.html">
                                                    <img src="assets/images/blog/index5/post4.jpg" alt="Entry">
                                                </a>
                                            </figure>
                                            <div class="entry-content-wrapper">
                                                <span class="entry-date">10 October</span>
                                                <h2 class="entry-title">
                                                    <a href="single.html">Nullam vulp utate conval</a>
                                                </h2>
                                                <div class="entry-content">
                                                     <p>Vivamus mollis varius metus in egestas. Vestibulum blandit auctor dolor. Praesent iaculis ultrices accumsan. Integer sollicitu din consectetur lectus, vitae vulputate velit pharetra sed. Nunc ac lobortis velit, eu tempus tellus.</p>
                                                </div><!-- End .entry-excerpt -->
                                                <a href="sigle.html" class="btn btn-custom btn-readmore">READ MORE</a>
                                            </div><!-- End .entry-content-wrapper -->
                                        </article>
                                    </div><!-- End .swiper-slide -->
                                </div><!-- End .swiper-wrapper -->
                            </div><!-- End .swiper-container -->