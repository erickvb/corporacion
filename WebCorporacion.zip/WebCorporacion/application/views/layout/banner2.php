<div class="banner-row-container">
                                <div class="row">
                                    <div class="banner-main-col">
                                        <div class="banner v6 bigger wow zoomIn">
                                            <a href="#">
                                                <img src="<?=base_url()?>public/assets/images/banners/index5/banner3.jpg" alt="Banner">
                                            </a>
                                            <div class="banner-content right light">
                                                <h4>Exclusive</h4>
                                                <h3><span>Discounts</span>&amp; OFfers</h3>
                                                <p>Lorem ipsum dolor sit amet, consectetur<br>adipiscing elit mauris finibus.</p>
                                                <a href="#" class="btn btn-custom">Read more</a>
                                            </div><!-- End .banner-content -->
                                        </div><!-- End .banner -->
                                    </div>
                                    <div class="banner-side-col">
                                        <div class="banner v6 wow zoomIn" data-wow-delay="0.15s">
                                            <a href="#">
                                                <img src="<?=base_url()?>public/assets/images/banners/index5/banner4.jpg" alt="Banner">
                                            </a>
                                            <div class="banner-content">
                                                <h4>see the great</h4>
                                                <h3><span>Attention</span>to Details</h3>
                                                <a href="#" class="btn btn-custom">Take a Look</a>
                                            </div><!-- End .banner-content -->
                                        </div><!-- End .banner -->
                                        <div class="banner v6 wow zoomIn" data-wow-delay="0.3s">
                                            <a href="#">
                                                <img src="<?=base_url()?>public/assets/images/banners/index5/banner5.jpg" alt="Banner">
                                            </a>
                                            <div class="banner-content right">
                                                <h4>$100 diccount off the </h4>
                                                <h3><span>Windows</span>Phone</h3>
                                                <a href="#" class="btn btn-custom">Order now</a>
                                            </div><!-- End .banner-content -->
                                        </div><!-- End .banner -->
                                    </div>
                                </div><!-- End .row -->
                            </div><!-- End .banner-row-container -->