<section id="jm-bottom2" class="">
<div class="container-fluid"><div
class="row-fluid jm-flexiblock jm-bottom2"><div
class="span4"  data-default="span4" data-wide="span4" data-normal="span4" data-xtablet="span4" data-tablet="span100" data-mobile="span100"><div
class="row-fluid"><div
class="span0"><div
class="jm-module "><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>People</span> from your area</h3></div><div
class="jm-module-content clearfix "><div
class="dj_cf_maps"><div
id="djmod_map_box201" style="display:none;"><div
id='djmod_map201' class="djmod_map" style='width: 100%; height: 300px; border: 1px solid #666; '></div></div></div> 

		     </div></div></div></div></div></div><div
class="span4"  data-default="span4" data-wide="span4" data-normal="span4" data-xtablet="span4" data-tablet="span100 first-span" data-mobile="span100 first-span"><div
class="row-fluid"><div
class="span0"><div
class="jm-module "><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Most</span> Recent Ads</h3></div><div
class="jm-module-content clearfix "><div
style="border: 0px !important;"><ul
id="djkwicks31m265" class="kwicks kwicks-horizontal"><li
class="djpanel-1 kwicks-selected">
<a
href="jm-dating/single-ad-view-with-bids" target="_self"><span
class="dj-image" style="background-image: url(jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/grayscale-200x300-crop-90-78_i14.jpg)"><span
class="dj-image-color" style="background-image: url(jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/200x300-crop-90-78_i14.jpg)"></span></span></a><div
class="dj-slide-desc"></div></li><li
class="djpanel-2">
<a
href="jm-dating/single-ad-view-with-buy-now" target="_self"><span
class="dj-image" style="background-image: url(jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/grayscale-200x300-crop-90-77_i24.jpg)"><span
class="dj-image-color" style="background-image: url(jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/200x300-crop-90-77_i24.jpg)"></span></span></a><div
class="dj-slide-desc"></div></li><li
class="djpanel-3">
<a
href="jm-dating/meet-somebody/she-s-looking-for-him/ad/felicia-owen,76" target="_self"><span
class="dj-image" style="background-image: url(jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/grayscale-200x300-crop-90-76_i8.jpg)"><span
class="dj-image-color" style="background-image: url(jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/200x300-crop-90-76_i8.jpg)"></span></span></a><div
class="dj-slide-desc"></div></li><li
class="djpanel-4">
<a
href="jm-dating/single-ad-view-with-horizontal-search" target="_self"><span
class="dj-image" style="background-image: url(jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/grayscale-200x300-crop-90-75_i6.jpg)"><span
class="dj-image-color" style="background-image: url(jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/200x300-crop-90-75_i6.jpg)"></span></span></a><div
class="dj-slide-desc"></div></li></ul></div><div
style="clear: both"></div></div></div></div></div></div></div><div
class="span4"  data-default="span4" data-wide="span4" data-normal="span4" data-xtablet="span4" data-tablet="span100 first-span" data-mobile="span100 first-span"><div
class="row-fluid"><div
class="span0"><div
class="jm-module "><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Love</span> story !</h3></div><div
class="jm-module-content clearfix "><div
class="custom"  ><p><a
href="jm-dating/contact"><img src="jm-dating/images/modules/banner-bottom.jpg" alt="Love Story" /></a></p></div></div></div></div></div></div></div></div></div>
</section>
