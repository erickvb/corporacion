<aside id="jm-left" class="span3 offset-12" data-xtablet="span12 first-span" data-tablet="span12 first-span" data-mobile="span12 first-span">
<div class=""><div
class="row-fluid"><div
class="span0"><div
class="jm-module _menu white-ms"><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Categories</span></h3></div><div
class="jm-module-content clearfix "><div
class="djcf_menu"><ul
class="menu nav _menu white-ms"><li
class=""><a
href="jm-dating/meet-somebody/he-s-looking-for-her">He's looking for Her</a></li><li
class="active current"><a
href="jm-dating/meet-somebody/she-s-looking-for-him">She's looking for Him</a></li><li
class=""><a
href="jm-dating/meet-somebody/she-s-looking-for-her">She's looking for Her - Adults only</a></li><li
class=""><a
href="jm-dating/meet-somebody/he-s-looking-for-him">He's looking for Him</a></li></ul><div
class="newad_link_bottom"><a
class="button" href="jm-dating/join-us">Join Us!</a></div></div></div></div></div></div></div><div
class="row-fluid"><div
class="span0"><div
class="jm-module _menu white-ms"><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Regions</span></h3></div><div
class="jm-module-content clearfix "><div
class="djcf_menu djcf_regions"><ul
class="menu nav"><li ><a
href="jm-dating/category-table-smart?se=1&amp;re=1&amp;se_regs=1">North America</a></li></ul></div></div></div></div></div></div><div
class="row-fluid"><div
class="span0"><div
class="jm-module  white-ms"><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Search</span></h3></div><div
class="jm-module-content clearfix "><div
id="mod_djcf_search206" class="dj_cf_search"><form
action="jm-dating/category-table-rwd?se=1" method="get" name="form-search206" id="form-search206">
<input
type="hidden" name="se" value="1" />
<input
type="hidden" name="task" value="parsesearch" /><div
class="search_word djcf_se_row">
<input
type="text" size="12" name="search" class="inputbox first_input" value="Search for singles..." onfocus="if(this.value=='Search for singles...') this.value='';" onblur="if (this.value=='') this.value='Search for singles...';" /></div><div
class="search_regions djcf_se_row">
<select
class="inputbox" id="se206_reg_0" name="se_regs[]" onchange="se206_new_reg(0,this.value,new Array());"><option
value="0">Location</option><option
value="1">North America</option></select><div
id="se206_after_reg_0"></div> 
 </div><div
class="search_cats djcf_se_row">
<select
class="inputbox" id="se206_cat_0" name="se_cats[]" onchange="se206_new_cat(0,this.value,new Array());se206_getFields(this.value);"><option
value="">Choose gender</option><option
value="9">He&apos;s looking for Her</option><option
value="15">She&apos;s looking for Him</option><option
value="25">She&apos;s looking for Her - Adults only</option><option
value="26">He&apos;s looking for Him</option></select><div
id="se206_after_cat_0"></div>
 </div><div
style="clear:both"></div><div
id="search206_ex_fields" class="search_ex_fields no_fields"></div><div
style="clear:both"></div><div
class="search_time djcf_se_row">
<select
name="days_l" class="inputbox" ><option
SELECTED  value="">Any time</option><option
value="1">Past 24 hours</option><option
value="3">Past 3 days</option><option
value="7">Past week</option><option
value="30">Past month</option>
</select></div><div
class="search_buttons">
<button
type="submit" class="button btn">Search</button>
<a
href="jm-dating/category-table-rwd?reset=1" class="reset_button">Reset</a></div></form><div
style="clear:both"></div></div></div></div></div></div></div><div
class="row-fluid"><div
class="span0"><div
class="jm-module  title-color-ms"><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Most</span> Popular Profiles</h3></div><div
class="jm-module-content clearfix "><div
class="mod_djclassifieds_items clearfix"><div
class="items items-cols1"><div
class="items-col icol1"><div
class="icol-in"><div
class="item"><div
class="title"><a
class="title_img" href="jm-dating/single-ad-view-with-bids"><img
style="" src="jm-dating/components/com_djclassifieds/images/item/78_i14_thb.jpg" alt="Vivian White" title="i14" /></a><a
class="title" href="jm-dating/single-ad-view-with-bids">Vivian White</a><div
class="date_cat"><span
class="category"><a
class="title_cat" href="jm-dating/meet-somebody/she-s-looking-for-him">She's looking for Him</a></span></div></div></div><div
class="clear_both"></div></div></div></div></div></div></div></div></div></div><div
class="row-fluid"><div
class="span0"><div
class="jm-module  title-color-ms"><div
class="jm-module-in"><div
class="jm-title-wrap"><h3 class="jm-title "><span>Recent</span> Singles</h3></div><div
class="jm-module-content clearfix "><div
style="border: 0px !important;"><div
id="dj-mslider30m267" class="dj-mslider"><div
class="dj-mslider-in"><div
class="dj-slides"><div
class="dj-slide"><div
class="dj-slide-in">
<a
href="jm-dating/single-ad-view-with-bids" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/270x250-crop-90-78_i14.jpg"  data-srcset="jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/270x250-crop-90-78_i14.jpg 270w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_240w/270x250-crop-90-78_i14.jpg 240w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_160w/270x250-crop-90-78_i14.jpg 160w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_120w/270x250-crop-90-78_i14.jpg 120w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_80w/270x250-crop-90-78_i14.jpg 80w" data-sizes="100vw" alt="Vivian White" class="dj-image" width="270" height="250" /></a></div></div><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/single-ad-view-with-bids" target="_self">										Vivian White									</a></div><div
style="clear: both"></div></div></div></div><div
class="dj-slide"><div
class="dj-slide-in">
<a
href="jm-dating/single-ad-view-with-buy-now" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/270x250-crop-90-77_i24.jpg"  data-srcset="jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/270x250-crop-90-77_i24.jpg 270w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_240w/270x250-crop-90-77_i24.jpg 240w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_160w/270x250-crop-90-77_i24.jpg 160w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_120w/270x250-crop-90-77_i24.jpg 120w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_80w/270x250-crop-90-77_i24.jpg 80w" data-sizes="100vw" alt="Henry Garrett " class="dj-image" width="270" height="250" /></a></div></div><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/single-ad-view-with-buy-now" target="_self">										Henry Garrett 									</a></div><div
style="clear: both"></div></div></div></div><div
class="dj-slide"><div
class="dj-slide-in">
<a
href="jm-dating/meet-somebody/she-s-looking-for-him/ad/felicia-owen,76" target="_self"><img
src="jm-dating/components/com_djmediatools/assets/images/blank.gif" data-src="jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/270x250-crop-90-76_i8.jpg"  data-srcset="jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/270x250-crop-90-76_i8.jpg 270w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_240w/270x250-crop-90-76_i8.jpg 240w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_160w/270x250-crop-90-76_i8.jpg 160w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_120w/270x250-crop-90-76_i8.jpg 120w, jm-dating/media/djmediatools/cache//components/com_djclassifieds/images/item/_80w/270x250-crop-90-76_i8.jpg 80w" data-sizes="100vw" alt="Felicia Owen " class="dj-image" width="270" height="250" /></a></div></div><div
class="dj-slide-desc"><div
class="dj-slide-desc-in"><div
class="dj-slide-desc-bg"></div><div
class="dj-slide-desc-text"><div
class="dj-slide-title">
<a
href="jm-dating/meet-somebody/she-s-looking-for-him/ad/felicia-owen,76" target="_self">										Felicia Owen 									</a></div><div
style="clear: both"></div></div></div></div></div><div
class="dj-navigation"><div
class="dj-navigation-in"></div></div><div
class="dj-indicators "><div
class="dj-indicators-in">
<span
class="dj-load-button dj-load-button-active"><span
class="dj-key"></span></span>
<span
class="dj-load-button"><span
class="dj-key"></span></span>
<span
class="dj-load-button"><span
class="dj-key"></span></span></div></div><div
class="dj-loader"></div></div></div></div><div
style="clear: both"></div></div></div></div></div></div></div>
</aside>