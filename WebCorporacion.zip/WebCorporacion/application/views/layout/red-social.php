<section id="jm-bottom3" class=""><div
class="container-fluid"><div
class="row-fluid jm-flexiblock jm-bottom3"><div
class="span12"  data-default="span12" data-wide="span12" data-normal="span12" data-xtablet="span12" data-tablet="span100" data-mobile="span100"><div
class="row-fluid"><div
class="span0"><div
class="jm-module "><div
class="jm-module-in"><div
class="jm-module-content clearfix notitle"><div
class="custom"  ><div
class="jm-social"><div
class="jm-icons"><div
class="jm-social-title">Follow us on</div>
<a
class="jm-facebook" href="#"> </a> <a
class="jm-twitter" href="#"> </a> <a
class="jm-google" href="#"> </a> <a
class="jm-pinterest" href="#"> </a></div></div></div></div></div></div></div></div></div></div></div>
</section>