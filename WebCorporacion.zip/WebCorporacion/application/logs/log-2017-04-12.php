<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-12 16:18:50 --> Config Class Initialized
INFO - 2017-04-12 16:18:50 --> Hooks Class Initialized
INFO - 2017-04-12 16:18:50 --> Utf8 Class Initialized
INFO - 2017-04-12 16:18:50 --> URI Class Initialized
INFO - 2017-04-12 16:18:50 --> Router Class Initialized
INFO - 2017-04-12 16:18:50 --> Output Class Initialized
INFO - 2017-04-12 16:18:50 --> Security Class Initialized
INFO - 2017-04-12 16:18:50 --> CSRF cookie sent
INFO - 2017-04-12 16:18:50 --> Input Class Initialized
INFO - 2017-04-12 16:18:50 --> Language Class Initialized
INFO - 2017-04-12 16:18:50 --> Loader Class Initialized
INFO - 2017-04-12 16:18:50 --> Helper loaded: url_helper
INFO - 2017-04-12 16:18:50 --> Helper loaded: file_helper
INFO - 2017-04-12 16:18:50 --> Helper loaded: form_helper
INFO - 2017-04-12 16:18:50 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 16:18:50 --> Database Driver Class Initialized
ERROR - 2017-04-12 16:19:11 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '173.201.88.132' (10060) C:\AppServ\www\webcorpo\system\database\drivers\mysql\mysql_driver.php 136
ERROR - 2017-04-12 16:19:11 --> Severity: Warning --> mysql_select_db(): supplied argument is not a valid MySQL-Link resource C:\AppServ\www\webcorpo\system\database\drivers\mysql\mysql_driver.php 208
ERROR - 2017-04-12 16:19:11 --> Unable to select database: adminServicios
INFO - 2017-04-12 16:19:11 --> Language file loaded: language/english/db_lang.php
INFO - 2017-04-12 16:23:27 --> Config Class Initialized
INFO - 2017-04-12 16:23:27 --> Hooks Class Initialized
INFO - 2017-04-12 16:23:27 --> Utf8 Class Initialized
INFO - 2017-04-12 16:23:27 --> URI Class Initialized
INFO - 2017-04-12 16:23:27 --> Router Class Initialized
INFO - 2017-04-12 16:23:27 --> Output Class Initialized
INFO - 2017-04-12 16:23:27 --> Security Class Initialized
INFO - 2017-04-12 16:23:27 --> CSRF cookie sent
INFO - 2017-04-12 16:23:27 --> Input Class Initialized
INFO - 2017-04-12 16:23:27 --> Language Class Initialized
INFO - 2017-04-12 16:23:27 --> Loader Class Initialized
INFO - 2017-04-12 16:23:27 --> Helper loaded: url_helper
INFO - 2017-04-12 16:23:27 --> Helper loaded: file_helper
INFO - 2017-04-12 16:23:27 --> Helper loaded: form_helper
INFO - 2017-04-12 16:23:27 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 16:23:27 --> Database Driver Class Initialized
ERROR - 2017-04-12 16:23:48 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '173.201.88.132' (10060) C:\AppServ\www\webcorpo\system\database\drivers\mysql\mysql_driver.php 136
ERROR - 2017-04-12 16:23:48 --> Severity: Warning --> mysql_select_db(): supplied argument is not a valid MySQL-Link resource C:\AppServ\www\webcorpo\system\database\drivers\mysql\mysql_driver.php 208
ERROR - 2017-04-12 16:23:48 --> Unable to select database: adminServicios
INFO - 2017-04-12 16:23:48 --> Language file loaded: language/english/db_lang.php
INFO - 2017-04-12 16:25:07 --> Config Class Initialized
INFO - 2017-04-12 16:25:07 --> Hooks Class Initialized
INFO - 2017-04-12 16:25:07 --> Utf8 Class Initialized
INFO - 2017-04-12 16:25:07 --> URI Class Initialized
INFO - 2017-04-12 16:25:07 --> Router Class Initialized
INFO - 2017-04-12 16:25:07 --> Output Class Initialized
INFO - 2017-04-12 16:25:07 --> Security Class Initialized
INFO - 2017-04-12 16:25:07 --> CSRF cookie sent
INFO - 2017-04-12 16:25:07 --> Input Class Initialized
INFO - 2017-04-12 16:25:07 --> Language Class Initialized
INFO - 2017-04-12 16:25:07 --> Loader Class Initialized
INFO - 2017-04-12 16:25:07 --> Helper loaded: url_helper
INFO - 2017-04-12 16:25:07 --> Helper loaded: file_helper
INFO - 2017-04-12 16:25:07 --> Helper loaded: form_helper
INFO - 2017-04-12 16:25:07 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 16:25:07 --> Database Driver Class Initialized
ERROR - 2017-04-12 16:25:28 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '173.201.88.132' (10060) C:\AppServ\www\webcorpo\system\database\drivers\mysql\mysql_driver.php 136
ERROR - 2017-04-12 16:25:28 --> Severity: Warning --> mysql_select_db(): supplied argument is not a valid MySQL-Link resource C:\AppServ\www\webcorpo\system\database\drivers\mysql\mysql_driver.php 208
ERROR - 2017-04-12 16:25:28 --> Unable to select database: adminServicios
INFO - 2017-04-12 16:25:28 --> Language file loaded: language/english/db_lang.php
INFO - 2017-04-12 16:25:41 --> Config Class Initialized
INFO - 2017-04-12 16:25:41 --> Hooks Class Initialized
INFO - 2017-04-12 16:25:41 --> Utf8 Class Initialized
INFO - 2017-04-12 16:25:41 --> URI Class Initialized
INFO - 2017-04-12 16:25:41 --> Router Class Initialized
INFO - 2017-04-12 16:25:42 --> Output Class Initialized
INFO - 2017-04-12 16:25:42 --> Security Class Initialized
INFO - 2017-04-12 16:25:42 --> CSRF cookie sent
INFO - 2017-04-12 16:25:42 --> Input Class Initialized
INFO - 2017-04-12 16:25:42 --> Language Class Initialized
INFO - 2017-04-12 16:25:42 --> Loader Class Initialized
INFO - 2017-04-12 16:25:42 --> Helper loaded: url_helper
INFO - 2017-04-12 16:25:42 --> Helper loaded: file_helper
INFO - 2017-04-12 16:25:42 --> Helper loaded: form_helper
INFO - 2017-04-12 16:25:42 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 16:25:42 --> Database Driver Class Initialized
INFO - 2017-04-12 16:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 16:25:42 --> Controller Class Initialized
INFO - 2017-04-12 16:25:42 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 16:25:42 --> Final output sent to browser
INFO - 2017-04-12 17:57:54 --> Config Class Initialized
INFO - 2017-04-12 17:57:54 --> Hooks Class Initialized
INFO - 2017-04-12 17:57:54 --> Utf8 Class Initialized
INFO - 2017-04-12 17:57:54 --> URI Class Initialized
INFO - 2017-04-12 17:57:54 --> Router Class Initialized
INFO - 2017-04-12 17:57:54 --> Output Class Initialized
INFO - 2017-04-12 17:57:54 --> Security Class Initialized
INFO - 2017-04-12 17:57:54 --> CSRF cookie sent
INFO - 2017-04-12 17:57:54 --> Input Class Initialized
INFO - 2017-04-12 17:57:54 --> Language Class Initialized
INFO - 2017-04-12 17:57:54 --> Loader Class Initialized
INFO - 2017-04-12 17:57:54 --> Helper loaded: url_helper
INFO - 2017-04-12 17:57:54 --> Helper loaded: file_helper
INFO - 2017-04-12 17:57:54 --> Helper loaded: form_helper
INFO - 2017-04-12 17:57:54 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 17:57:54 --> Database Driver Class Initialized
INFO - 2017-04-12 17:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 17:57:54 --> Controller Class Initialized
INFO - 2017-04-12 17:57:54 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 17:57:54 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 17:57:54 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 17:57:54 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 17:57:54 --> Final output sent to browser
INFO - 2017-04-12 18:17:52 --> Config Class Initialized
INFO - 2017-04-12 18:17:52 --> Hooks Class Initialized
INFO - 2017-04-12 18:17:52 --> Utf8 Class Initialized
INFO - 2017-04-12 18:17:52 --> URI Class Initialized
INFO - 2017-04-12 18:17:52 --> Router Class Initialized
INFO - 2017-04-12 18:17:52 --> Output Class Initialized
INFO - 2017-04-12 18:17:52 --> Security Class Initialized
INFO - 2017-04-12 18:17:52 --> CSRF cookie sent
INFO - 2017-04-12 18:17:52 --> Input Class Initialized
INFO - 2017-04-12 18:17:52 --> Language Class Initialized
INFO - 2017-04-12 18:17:52 --> Loader Class Initialized
INFO - 2017-04-12 18:17:52 --> Helper loaded: url_helper
INFO - 2017-04-12 18:17:52 --> Helper loaded: file_helper
INFO - 2017-04-12 18:17:52 --> Helper loaded: form_helper
INFO - 2017-04-12 18:17:52 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 18:17:52 --> Database Driver Class Initialized
INFO - 2017-04-12 18:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 18:17:52 --> Controller Class Initialized
INFO - 2017-04-12 18:17:52 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 18:17:52 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 18:17:52 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 18:17:52 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 18:17:52 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 18:17:52 --> Final output sent to browser
INFO - 2017-04-12 18:23:15 --> Config Class Initialized
INFO - 2017-04-12 18:23:15 --> Hooks Class Initialized
INFO - 2017-04-12 18:23:15 --> Utf8 Class Initialized
INFO - 2017-04-12 18:23:15 --> URI Class Initialized
INFO - 2017-04-12 18:23:15 --> Router Class Initialized
INFO - 2017-04-12 18:23:15 --> Output Class Initialized
INFO - 2017-04-12 18:23:15 --> Security Class Initialized
INFO - 2017-04-12 18:23:15 --> CSRF cookie sent
INFO - 2017-04-12 18:23:15 --> Input Class Initialized
INFO - 2017-04-12 18:23:15 --> Language Class Initialized
INFO - 2017-04-12 18:23:15 --> Loader Class Initialized
INFO - 2017-04-12 18:23:15 --> Helper loaded: url_helper
INFO - 2017-04-12 18:23:15 --> Helper loaded: file_helper
INFO - 2017-04-12 18:23:15 --> Helper loaded: form_helper
INFO - 2017-04-12 18:23:15 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 18:23:15 --> Database Driver Class Initialized
INFO - 2017-04-12 18:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 18:23:15 --> Controller Class Initialized
INFO - 2017-04-12 18:23:15 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 18:23:15 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 18:23:15 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 18:23:15 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 18:23:15 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 18:23:15 --> Final output sent to browser
INFO - 2017-04-12 18:29:12 --> Config Class Initialized
INFO - 2017-04-12 18:29:12 --> Hooks Class Initialized
INFO - 2017-04-12 18:29:12 --> Utf8 Class Initialized
INFO - 2017-04-12 18:29:12 --> URI Class Initialized
INFO - 2017-04-12 18:29:12 --> Router Class Initialized
INFO - 2017-04-12 18:29:12 --> Output Class Initialized
INFO - 2017-04-12 18:29:12 --> Security Class Initialized
INFO - 2017-04-12 18:29:12 --> CSRF cookie sent
INFO - 2017-04-12 18:29:12 --> Input Class Initialized
INFO - 2017-04-12 18:29:12 --> Language Class Initialized
INFO - 2017-04-12 18:29:12 --> Loader Class Initialized
INFO - 2017-04-12 18:29:12 --> Helper loaded: url_helper
INFO - 2017-04-12 18:29:12 --> Helper loaded: file_helper
INFO - 2017-04-12 18:29:12 --> Helper loaded: form_helper
INFO - 2017-04-12 18:29:12 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 18:29:12 --> Database Driver Class Initialized
INFO - 2017-04-12 18:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 18:29:12 --> Controller Class Initialized
INFO - 2017-04-12 18:29:12 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 18:29:12 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 18:29:12 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 18:29:12 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 18:29:12 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 18:29:12 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 18:29:12 --> Final output sent to browser
INFO - 2017-04-12 18:29:53 --> Config Class Initialized
INFO - 2017-04-12 18:29:53 --> Hooks Class Initialized
INFO - 2017-04-12 18:29:53 --> Utf8 Class Initialized
INFO - 2017-04-12 18:29:53 --> URI Class Initialized
INFO - 2017-04-12 18:29:53 --> Router Class Initialized
INFO - 2017-04-12 18:29:53 --> Output Class Initialized
INFO - 2017-04-12 18:29:53 --> Security Class Initialized
INFO - 2017-04-12 18:29:53 --> CSRF cookie sent
INFO - 2017-04-12 18:29:53 --> Input Class Initialized
INFO - 2017-04-12 18:29:53 --> Language Class Initialized
INFO - 2017-04-12 18:29:53 --> Loader Class Initialized
INFO - 2017-04-12 18:29:53 --> Helper loaded: url_helper
INFO - 2017-04-12 18:29:53 --> Helper loaded: file_helper
INFO - 2017-04-12 18:29:53 --> Helper loaded: form_helper
INFO - 2017-04-12 18:29:53 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 18:29:53 --> Database Driver Class Initialized
INFO - 2017-04-12 18:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 18:29:53 --> Controller Class Initialized
INFO - 2017-04-12 18:29:53 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 18:29:53 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 18:29:53 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 18:29:53 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 18:29:53 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 18:29:53 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 18:29:53 --> Final output sent to browser
INFO - 2017-04-12 18:32:10 --> Config Class Initialized
INFO - 2017-04-12 18:32:10 --> Hooks Class Initialized
INFO - 2017-04-12 18:32:10 --> Utf8 Class Initialized
INFO - 2017-04-12 18:32:10 --> URI Class Initialized
INFO - 2017-04-12 18:32:10 --> Router Class Initialized
INFO - 2017-04-12 18:32:10 --> Output Class Initialized
INFO - 2017-04-12 18:32:10 --> Security Class Initialized
INFO - 2017-04-12 18:32:10 --> CSRF cookie sent
INFO - 2017-04-12 18:32:10 --> Input Class Initialized
INFO - 2017-04-12 18:32:10 --> Language Class Initialized
INFO - 2017-04-12 18:32:10 --> Loader Class Initialized
INFO - 2017-04-12 18:32:10 --> Helper loaded: url_helper
INFO - 2017-04-12 18:32:10 --> Helper loaded: file_helper
INFO - 2017-04-12 18:32:10 --> Helper loaded: form_helper
INFO - 2017-04-12 18:32:10 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 18:32:10 --> Database Driver Class Initialized
INFO - 2017-04-12 18:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 18:32:10 --> Controller Class Initialized
INFO - 2017-04-12 18:32:10 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 18:32:10 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 18:32:10 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 18:32:10 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 18:32:10 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 18:32:10 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 18:32:10 --> Final output sent to browser
INFO - 2017-04-12 18:39:45 --> Config Class Initialized
INFO - 2017-04-12 18:39:45 --> Hooks Class Initialized
INFO - 2017-04-12 18:39:45 --> Utf8 Class Initialized
INFO - 2017-04-12 18:39:45 --> URI Class Initialized
INFO - 2017-04-12 18:39:45 --> Router Class Initialized
INFO - 2017-04-12 18:39:45 --> Output Class Initialized
INFO - 2017-04-12 18:39:45 --> Security Class Initialized
INFO - 2017-04-12 18:39:45 --> CSRF cookie sent
INFO - 2017-04-12 18:39:45 --> Input Class Initialized
INFO - 2017-04-12 18:39:45 --> Language Class Initialized
INFO - 2017-04-12 18:39:45 --> Loader Class Initialized
INFO - 2017-04-12 18:39:45 --> Helper loaded: url_helper
INFO - 2017-04-12 18:39:45 --> Helper loaded: file_helper
INFO - 2017-04-12 18:39:45 --> Helper loaded: form_helper
INFO - 2017-04-12 18:39:45 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 18:39:45 --> Database Driver Class Initialized
INFO - 2017-04-12 18:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 18:39:45 --> Controller Class Initialized
INFO - 2017-04-12 18:39:45 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 18:39:45 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 18:39:45 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 18:39:45 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/especial-productos.php
INFO - 2017-04-12 18:39:45 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 18:39:45 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 18:39:45 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 18:39:45 --> Final output sent to browser
INFO - 2017-04-12 18:42:50 --> Config Class Initialized
INFO - 2017-04-12 18:42:50 --> Hooks Class Initialized
INFO - 2017-04-12 18:42:50 --> Utf8 Class Initialized
INFO - 2017-04-12 18:42:50 --> URI Class Initialized
INFO - 2017-04-12 18:42:50 --> Router Class Initialized
INFO - 2017-04-12 18:42:50 --> Output Class Initialized
INFO - 2017-04-12 18:42:50 --> Security Class Initialized
INFO - 2017-04-12 18:42:50 --> CSRF cookie sent
INFO - 2017-04-12 18:42:50 --> Input Class Initialized
INFO - 2017-04-12 18:42:50 --> Language Class Initialized
INFO - 2017-04-12 18:42:50 --> Loader Class Initialized
INFO - 2017-04-12 18:42:50 --> Helper loaded: url_helper
INFO - 2017-04-12 18:42:50 --> Helper loaded: file_helper
INFO - 2017-04-12 18:42:50 --> Helper loaded: form_helper
INFO - 2017-04-12 18:42:50 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 18:42:50 --> Database Driver Class Initialized
INFO - 2017-04-12 18:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 18:42:50 --> Controller Class Initialized
INFO - 2017-04-12 18:42:50 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 18:42:50 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 18:42:50 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 18:42:50 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/especial-productos.php
INFO - 2017-04-12 18:42:50 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/manufacturer.php
INFO - 2017-04-12 18:42:50 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 18:42:50 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 18:42:50 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 18:42:50 --> Final output sent to browser
INFO - 2017-04-12 18:48:56 --> Config Class Initialized
INFO - 2017-04-12 18:48:56 --> Hooks Class Initialized
INFO - 2017-04-12 18:48:56 --> Utf8 Class Initialized
INFO - 2017-04-12 18:48:56 --> URI Class Initialized
INFO - 2017-04-12 18:48:56 --> Router Class Initialized
INFO - 2017-04-12 18:48:56 --> Output Class Initialized
INFO - 2017-04-12 18:48:56 --> Security Class Initialized
INFO - 2017-04-12 18:48:56 --> CSRF cookie sent
INFO - 2017-04-12 18:48:56 --> Input Class Initialized
INFO - 2017-04-12 18:48:56 --> Language Class Initialized
INFO - 2017-04-12 18:48:56 --> Loader Class Initialized
INFO - 2017-04-12 18:48:56 --> Helper loaded: url_helper
INFO - 2017-04-12 18:48:56 --> Helper loaded: file_helper
INFO - 2017-04-12 18:48:56 --> Helper loaded: form_helper
INFO - 2017-04-12 18:48:56 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 18:48:56 --> Database Driver Class Initialized
INFO - 2017-04-12 18:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 18:48:56 --> Controller Class Initialized
INFO - 2017-04-12 18:48:56 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 18:48:56 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 18:48:56 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 18:48:56 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/especial-productos.php
INFO - 2017-04-12 18:48:56 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/top-rating.php
INFO - 2017-04-12 18:48:56 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/manufacturer.php
INFO - 2017-04-12 18:48:56 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 18:48:56 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 18:48:56 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 18:48:56 --> Final output sent to browser
INFO - 2017-04-12 18:54:14 --> Config Class Initialized
INFO - 2017-04-12 18:54:14 --> Hooks Class Initialized
INFO - 2017-04-12 18:54:14 --> Utf8 Class Initialized
INFO - 2017-04-12 18:54:14 --> URI Class Initialized
INFO - 2017-04-12 18:54:14 --> Router Class Initialized
INFO - 2017-04-12 18:54:14 --> Output Class Initialized
INFO - 2017-04-12 18:54:14 --> Security Class Initialized
INFO - 2017-04-12 18:54:14 --> CSRF cookie sent
INFO - 2017-04-12 18:54:14 --> Input Class Initialized
INFO - 2017-04-12 18:54:14 --> Language Class Initialized
INFO - 2017-04-12 18:54:14 --> Loader Class Initialized
INFO - 2017-04-12 18:54:14 --> Helper loaded: url_helper
INFO - 2017-04-12 18:54:14 --> Helper loaded: file_helper
INFO - 2017-04-12 18:54:14 --> Helper loaded: form_helper
INFO - 2017-04-12 18:54:14 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 18:54:14 --> Database Driver Class Initialized
INFO - 2017-04-12 18:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 18:54:14 --> Controller Class Initialized
INFO - 2017-04-12 18:54:14 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 18:54:14 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 18:54:14 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 18:54:14 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/productos.php
INFO - 2017-04-12 18:54:14 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/especial-productos.php
INFO - 2017-04-12 18:54:14 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/top-rating.php
INFO - 2017-04-12 18:54:14 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/manufacturer.php
INFO - 2017-04-12 18:54:14 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 18:54:14 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 18:54:14 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 18:54:14 --> Final output sent to browser
INFO - 2017-04-12 18:59:43 --> Config Class Initialized
INFO - 2017-04-12 18:59:43 --> Hooks Class Initialized
INFO - 2017-04-12 18:59:43 --> Utf8 Class Initialized
INFO - 2017-04-12 18:59:43 --> URI Class Initialized
INFO - 2017-04-12 18:59:43 --> Router Class Initialized
INFO - 2017-04-12 18:59:43 --> Output Class Initialized
INFO - 2017-04-12 18:59:43 --> Security Class Initialized
INFO - 2017-04-12 18:59:43 --> CSRF cookie sent
INFO - 2017-04-12 18:59:43 --> Input Class Initialized
INFO - 2017-04-12 18:59:43 --> Language Class Initialized
INFO - 2017-04-12 18:59:43 --> Loader Class Initialized
INFO - 2017-04-12 18:59:43 --> Helper loaded: url_helper
INFO - 2017-04-12 18:59:43 --> Helper loaded: file_helper
INFO - 2017-04-12 18:59:43 --> Helper loaded: form_helper
INFO - 2017-04-12 18:59:43 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 18:59:43 --> Database Driver Class Initialized
INFO - 2017-04-12 18:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 18:59:43 --> Controller Class Initialized
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/productos.php
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/especial-productos.php
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/top-rating.php
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/the-blog.php
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/manufacturer.php
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 18:59:43 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 18:59:43 --> Final output sent to browser
INFO - 2017-04-12 19:03:59 --> Config Class Initialized
INFO - 2017-04-12 19:03:59 --> Hooks Class Initialized
INFO - 2017-04-12 19:03:59 --> Utf8 Class Initialized
INFO - 2017-04-12 19:03:59 --> URI Class Initialized
INFO - 2017-04-12 19:03:59 --> Router Class Initialized
INFO - 2017-04-12 19:03:59 --> Output Class Initialized
INFO - 2017-04-12 19:03:59 --> Security Class Initialized
INFO - 2017-04-12 19:03:59 --> CSRF cookie sent
INFO - 2017-04-12 19:03:59 --> Input Class Initialized
INFO - 2017-04-12 19:03:59 --> Language Class Initialized
INFO - 2017-04-12 19:03:59 --> Loader Class Initialized
INFO - 2017-04-12 19:03:59 --> Helper loaded: url_helper
INFO - 2017-04-12 19:03:59 --> Helper loaded: file_helper
INFO - 2017-04-12 19:03:59 --> Helper loaded: form_helper
INFO - 2017-04-12 19:03:59 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 19:03:59 --> Database Driver Class Initialized
INFO - 2017-04-12 19:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 19:03:59 --> Controller Class Initialized
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/productos.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner2.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/especial-productos.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/fans-page.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/top-rating.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/the-blog.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/manufacturer.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 19:03:59 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 19:03:59 --> Final output sent to browser
INFO - 2017-04-12 19:04:32 --> Config Class Initialized
INFO - 2017-04-12 19:04:32 --> Hooks Class Initialized
INFO - 2017-04-12 19:04:32 --> Utf8 Class Initialized
INFO - 2017-04-12 19:04:32 --> URI Class Initialized
INFO - 2017-04-12 19:04:32 --> Router Class Initialized
INFO - 2017-04-12 19:04:32 --> Output Class Initialized
INFO - 2017-04-12 19:04:32 --> Security Class Initialized
INFO - 2017-04-12 19:04:32 --> CSRF cookie sent
INFO - 2017-04-12 19:04:32 --> Input Class Initialized
INFO - 2017-04-12 19:04:32 --> Language Class Initialized
INFO - 2017-04-12 19:04:32 --> Loader Class Initialized
INFO - 2017-04-12 19:04:32 --> Helper loaded: url_helper
INFO - 2017-04-12 19:04:32 --> Helper loaded: file_helper
INFO - 2017-04-12 19:04:32 --> Helper loaded: form_helper
INFO - 2017-04-12 19:04:32 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 19:04:32 --> Database Driver Class Initialized
INFO - 2017-04-12 19:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 19:04:32 --> Controller Class Initialized
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/productos.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner2.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/especial-productos.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/fans-page.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/top-rating.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/the-blog.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/manufacturer.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 19:04:32 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 19:04:32 --> Final output sent to browser
INFO - 2017-04-12 19:07:19 --> Config Class Initialized
INFO - 2017-04-12 19:07:19 --> Hooks Class Initialized
INFO - 2017-04-12 19:07:19 --> Utf8 Class Initialized
INFO - 2017-04-12 19:07:19 --> URI Class Initialized
INFO - 2017-04-12 19:07:19 --> Router Class Initialized
INFO - 2017-04-12 19:07:19 --> Output Class Initialized
INFO - 2017-04-12 19:07:19 --> Security Class Initialized
INFO - 2017-04-12 19:07:19 --> CSRF cookie sent
INFO - 2017-04-12 19:07:19 --> Input Class Initialized
INFO - 2017-04-12 19:07:19 --> Language Class Initialized
INFO - 2017-04-12 19:07:19 --> Loader Class Initialized
INFO - 2017-04-12 19:07:19 --> Helper loaded: url_helper
INFO - 2017-04-12 19:07:19 --> Helper loaded: file_helper
INFO - 2017-04-12 19:07:19 --> Helper loaded: form_helper
INFO - 2017-04-12 19:07:19 --> Helper loaded: tipo_usuario_helper
INFO - 2017-04-12 19:07:19 --> Database Driver Class Initialized
INFO - 2017-04-12 19:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-12 19:07:19 --> Controller Class Initialized
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/header.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/menu.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner-top.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/productos.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/banner2.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/especial-productos.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/fans-page.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/top-rating.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/the-blog.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/manufacturer.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/sidebar.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\layout/footer.php
INFO - 2017-04-12 19:07:19 --> File loaded: C:\AppServ\www\webcorpo\application\views\home.php
INFO - 2017-04-12 19:07:19 --> Final output sent to browser
