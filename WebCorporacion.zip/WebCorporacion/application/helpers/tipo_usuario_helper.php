<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require("splenum.php");
class Tipo_usuario  extends BasicEnum {
	const CLIENTE = 1;
	const SUSCRIPTOR =2;
// 	function function_name() {
// 		;
// 	}
}